#include <iostream>

using std::cout, std::cin, std::endl;

int hiddenSum (int n){
    int array[1000] = {0};
    int size = 0;
    int step = 10;
    int digit = 1;
    
    while (n > 0)
    {
        array[size] = (n % step) / digit;
        n -= n % step;
        size++;
        step *= 10;
        digit *= 10;
    }
    
	//since the array holds the values in reverse, the last index is the first digit of the number, check if it's 8
    if(array[size - 1] == 8)
        return 0;
    
    int sum = 0;
    for(int x = 0; x < size; x++)
        if(array[x] % 2 == 1)
            sum += array[x];
    return sum;
}

int main () {
	cout << hiddenSum(3775);	
}