#include <iostream>

using std::cout, std::cin, std::endl;

int main()
{
	int test[10] = { -12, 2, -2, 3, 5, -4, 78, -3, 19, 33};
	// the largest difference between values should be 82
	unsigned int answer = 0;
	
	// loop and compare 
	for (int x = 0; x < 9; x++)
	{
		if(test[x] < 0)
            test[x] *= -1;
	
		if(test[x + 1] < 0)
            test[x + 1] *= -1;
			
		if(test[x] + test[x + 1] > answer)
            answer = test[x] + test[x + 1];
	}
	
	cout << answer << " is the answer";
	return 0;	
}