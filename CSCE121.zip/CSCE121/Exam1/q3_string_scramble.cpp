#include <iostream>

using std::cout, std::cin, std::endl, std::string;

string scrambleWord(string word);

int main() {
	return 0;
}

string scrambleWord(string word) {
	
	//word.length() - 2 to make sure not to move last index
    for(int x = 1; x < word.length()-2; x++)
	{
        if((x % 2 == 0) && word[x] != 'o')
        {
           char temp = word[x];
            word[x] = word[x+1];
            word[x+1] = temp;
        }
	}
	return word;
}
