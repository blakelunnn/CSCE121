/*
----- Linked List Addition Problem -----
Implement the add function.
*/

#include "multi_digit_addition.h"
using std::ostream, std::cout, std::endl;

// copy constructor
Number::Number(const Number& other) : head(nullptr), tail(nullptr) {
    Digit* marker = other.head;
    while (nullptr != marker) {
        insertFront(marker->value);
        marker = marker->next;
    }
}

// destructor
Number::~Number() {
    // initialize auxiliary pointer
    Digit* marker = nullptr;

    // iterate through list
    while (nullptr != head) {
        // set pointer to head node
        marker = head;

        // move head node to next node
        head = head->next;

        // disconect current node from rest of linked list
        marker->next = nullptr;
        if (nullptr != head) {
            head->prev   = nullptr;
        }

        // deallocate pointer
        delete marker;
        marker = nullptr;
    }
}

// copy assignment operator
Number& Number::operator=(const Number& other) {
    throw std::runtime_error("do not use operator= function");
    if (this == &other) { return *this; }
    return *this;
}

// insert front
void Number::insertFront(int value) {
    // create new node
    Digit* digit = new Digit(value);

    // case: list is empty => set tail node
    if (nullptr == tail) {
        tail = digit;
    }

    // case: list is non-empty => link head to new node
    else {
        head->prev = digit;
    }

    // link node to head and update head
    digit->next = head;
    head = digit;
}

// insert back
void Number::insertBack(int value) {
    // create new node
    Digit* digit = new Digit(value);

    // case: list is empty => set head node
    if (nullptr == head) {
        head = digit;
    }

    // case: list is non-empty => link tail to new node
    else {
        tail->next = digit;
    }

    // link node to tail and update tail
    digit->prev = tail;
    tail = digit;
}

// insertion operator
ostream& operator<<(ostream& out, const Number& number) {
    Digit* marker = number.getHead();
    while (nullptr != marker) {
        out << marker->value;
        marker = marker->next;
    }
    return out;
}

/*
TODO: Implement add function
*/

// add function
Number Number::add(const Number& rhs) {
	if((this->head == nullptr || this->tail == nullptr) && rhs.head != nullptr && rhs.tail != nullptr) // in the case that one is nullptr and the other has value likes 50 + 0
		return rhs;
	if(this->head != nullptr && this->tail && nullptr && (rhs.head == nullptr || rhs.tail == nullptr)) // in the case that one is nullptr and the other has value likes 0 + 50
		return *this; 
	Number* newNumberList = new Number();
	Digit* digit1 = this->tail;
	Digit* digit2 = rhs.tail;
	
	int sumOfDigits = 0;
	int carriedValue = 0;
	while(digit1 != nullptr)
	{
		if(digit2 == nullptr)
		{
			sumOfDigits = digit1->value + carriedValue;
			if(sumOfDigits >= 10)
			{
				carriedValue = 1;
				sumOfDigits -= 10;
			}
			newNumberList->insertBack(sumOfDigits);
			digit1 = digit1->prev;
		}
		else
		{
			sumOfDigits = digit1->value + digit2->value + carriedValue;
			if(sumOfDigits >= 10)
			{
				carriedValue = 1;
				sumOfDigits -= 10;
			}
			else
				carriedValue = 0;
			
			newNumberList->insertBack(sumOfDigits);
			digit1 = digit1->prev;
			digit2 = digit2->prev;
		}
	}
	
	while(digit2 != nullptr)
	{	
		sumOfDigits = digit2->value + carriedValue;
		if(sumOfDigits >= 10)
		{
			carriedValue = 1;
			sumOfDigits -= 10;
		}
		newNumberList->insertBack(sumOfDigits);
		digit2 = digit2->prev;
	}
	if(carriedValue == 1)
		newNumberList->insertBack(1);
	
	return *newNumberList;
}